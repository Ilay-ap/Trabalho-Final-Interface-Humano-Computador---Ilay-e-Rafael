import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ihcProblems } from "@/data/problems";
import { Link, useParams } from "wouter";
import { ArrowLeft, X, Check } from "lucide-react";
import Header from "@/components/Header";
import { ModalLoginMockup, FormularioFeedbackMockup, LatamPassMockup, OfertasPrecoMockup, NavegacaoTabsMockup } from "@/components/mockups";

export default function Comparison() {
  const { id } = useParams<{ id: string }>();
  const problem = ihcProblems.find(p => p.id === id);

  if (!problem) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Problema não encontrado</h2>
          <Link href="/">
            <Button>Voltar para Início</Button>
          </Link>
        </div>
      </div>
    );
  }

  const renderMockup = (problemId: string, variant: "problem" | "solution") => {
    switch (problemId) {
      case "modal-login-intrusivo":
        return <ModalLoginMockup variant={variant} />;
      case "formulario-sem-feedback":
        return <FormularioFeedbackMockup variant={variant} />;
      case "jargao-latam-pass":
        return <LatamPassMockup variant={variant} />;
      case "ofertas-sem-contexto":
        return <OfertasPrecoMockup variant={variant} />;
      case "navegacao-complexa":
        return <NavegacaoTabsMockup variant={variant} />;
      default:
        return <p className="text-center text-slate-500 italic">Mockup em desenvolvimento</p>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        {/* Breadcrumb */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar para Lista de Problemas
            </Button>
          </Link>
        </div>

        {/* Título */}
        <div className="mb-8 text-center">
          <Badge className="mb-4 bg-purple-100 text-purple-700 hover:bg-purple-200">
            Comparação Antes/Depois
          </Badge>
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            {problem.title}
          </h1>
          <p className="text-lg text-slate-600">
            Heurística #{problem.heuristicNumber}: {problem.heuristic}
          </p>
        </div>

        {/* Tabs para Mobile e Desktop */}
        <Tabs defaultValue="side-by-side" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="side-by-side">Lado a Lado</TabsTrigger>
            <TabsTrigger value="stacked">Empilhado</TabsTrigger>
          </TabsList>

          {/* Visualização Lado a Lado */}
          <TabsContent value="side-by-side">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* ANTES - Problema */}
              <Card className="p-6 border-2 border-red-300 bg-red-50">
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-red-500 p-2 rounded-lg">
                    <X className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-red-900">ANTES</h2>
                    <p className="text-sm text-red-700">Interface com Problema</p>
                  </div>
                </div>

                <div className="bg-white rounded-lg overflow-hidden mb-4">
                  {renderMockup(problem.id, "problem")}
                </div>

                <div className="bg-red-100 p-4 rounded-lg border border-red-300">
                  <p className="text-sm text-red-900 font-semibold mb-2">❌ Problemas Identificados:</p>
                  <p className="text-sm text-red-800">
                    {problem.shortDescription}
                  </p>
                </div>
              </Card>

              {/* DEPOIS - Solução */}
              <Card className="p-6 border-2 border-green-300 bg-green-50">
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-green-500 p-2 rounded-lg">
                    <Check className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-green-900">DEPOIS</h2>
                    <p className="text-sm text-green-700">Interface Redesenhada</p>
                  </div>
                </div>

                <div className="bg-white rounded-lg overflow-hidden mb-4">
                  {renderMockup(problem.id, "solution")}
                </div>

                <div className="bg-green-100 p-4 rounded-lg border border-green-300">
                  <p className="text-sm text-green-900 font-semibold mb-2">✅ Melhorias Aplicadas:</p>
                  <p className="text-sm text-green-800">
                    {problem.redesignProposal}
                  </p>
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Visualização Empilhada */}
          <TabsContent value="stacked">
            <div className="space-y-8 max-w-5xl mx-auto">
              {/* ANTES */}
              <Card className="p-6 border-2 border-red-300 bg-red-50">
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-red-500 p-2 rounded-lg">
                    <X className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-red-900">ANTES - Interface com Problema</h2>
                  </div>
                </div>

                <div className="bg-white rounded-lg overflow-hidden mb-4">
                  {renderMockup(problem.id, "problem")}
                </div>

                <div className="bg-red-100 p-4 rounded-lg border border-red-300">
                  <p className="text-sm text-red-900 font-semibold mb-2">❌ Problemas Identificados:</p>
                  <p className="text-sm text-red-800">
                    {problem.shortDescription}
                  </p>
                </div>
              </Card>

              {/* DEPOIS */}
              <Card className="p-6 border-2 border-green-300 bg-green-50">
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-green-500 p-2 rounded-lg">
                    <Check className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-green-900">DEPOIS - Interface Redesenhada</h2>
                  </div>
                </div>

                <div className="bg-white rounded-lg overflow-hidden mb-4">
                  {renderMockup(problem.id, "solution")}
                </div>

                <div className="bg-green-100 p-4 rounded-lg border border-green-300">
                  <p className="text-sm text-green-900 font-semibold mb-2">✅ Melhorias Aplicadas:</p>
                  <p className="text-sm text-green-800">
                    {problem.redesignProposal}
                  </p>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Ações */}
        <div className="flex gap-4 justify-center mt-12">
          <Link href={`/problema/${problem.id}`}>
            <Button size="lg" variant="outline">
              Ver Detalhes Completos
            </Button>
          </Link>
          <Link href="/">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Voltar para Lista
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
