import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ihcProblems } from "@/data/problems";
import { Link, useParams } from "wouter";
import { ArrowLeft, AlertCircle, CheckCircle, BookOpen, User, Lightbulb } from "lucide-react";
import Header from "@/components/Header";
import { ModalLoginMockup, FormularioFeedbackMockup, LatamPassMockup, OfertasPrecoMockup, NavegacaoTabsMockup } from "@/components/mockups";

export default function ProblemDetail() {
  const { id } = useParams<{ id: string }>();
  const problem = ihcProblems.find(p => p.id === id);

  if (!problem) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
        <Header />
        <div className="container mx-auto px-4 py-12 text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Problema não encontrado</h2>
          <Link href="/">
            <Button>Voltar para Início</Button>
          </Link>
        </div>
      </div>
    );
  }

  const renderMockup = (problemId: string) => {
    switch (problemId) {
      case "modal-login-intrusivo":
        return <ModalLoginMockup variant="problem" />;
      case "formulario-sem-feedback":
        return <FormularioFeedbackMockup variant="problem" />;
      case "jargao-latam-pass":
        return <LatamPassMockup variant="problem" />;
      case "ofertas-sem-contexto":
        return <OfertasPrecoMockup variant="problem" />;
      case "navegacao-complexa":
        return <NavegacaoTabsMockup variant="problem" />;
      default:
        return <p className="text-center text-slate-500 italic">Mockup em desenvolvimento</p>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        {/* Breadcrumb */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar para Lista de Problemas
            </Button>
          </Link>
        </div>

        {/* Título */}
        <div className="mb-8">
          <Badge className="mb-4 bg-amber-100 text-amber-700 hover:bg-amber-200">
            Heurística #{problem.heuristicNumber}
          </Badge>
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            {problem.title}
          </h1>
          <p className="text-xl text-slate-600">
            {problem.heuristic}
          </p>
        </div>

        {/* Mockup Visual do Problema */}
        <Card className="p-6 mb-8 border-2 border-red-300 bg-red-50">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-red-500 p-2 rounded-lg">
              <AlertCircle className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-red-900">Visualização do Problema</h2>
          </div>
          
          <div className="bg-white rounded-lg overflow-hidden">
            {renderMockup(problem.id)}
          </div>
        </Card>

        {/* Seções de Análise */}
        <div className="space-y-6">
          {/* Descrição Detalhada */}
          <Card className="p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="h-6 w-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Descrição do Problema</h3>
                <p className="text-slate-700 leading-relaxed">
                  {problem.detailedDescription}
                </p>
              </div>
            </div>
          </Card>

          {/* Impacto no Usuário */}
          <Card className="p-6 bg-amber-50 border-2 border-amber-300">
            <div className="flex items-start gap-3 mb-4">
              <User className="h-6 w-6 text-amber-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-amber-900 mb-2">Impacto no Usuário Real</h3>
                <p className="text-amber-900 leading-relaxed italic">
                  {problem.userImpact}
                </p>
              </div>
            </div>
          </Card>

          {/* Fundamentação Teórica */}
          <Card className="p-6 bg-blue-50 border-2 border-blue-300">
            <div className="flex items-start gap-3 mb-4">
              <BookOpen className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-blue-900 mb-2">Fundamentação Teórica</h3>
                <p className="text-blue-900 leading-relaxed">
                  {problem.theoreticalJustification}
                </p>
              </div>
            </div>
          </Card>

          {/* Proposta de Redesign */}
          <Card className="p-6 bg-green-50 border-2 border-green-300">
            <div className="flex items-start gap-3 mb-4">
              <Lightbulb className="h-6 w-6 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-green-900 mb-2">Proposta de Redesign</h3>
                <p className="text-green-900 leading-relaxed">
                  {problem.redesignProposal}
                </p>
              </div>
            </div>
          </Card>

          {/* Exemplo do Mundo Real */}
          <Card className="p-6 bg-purple-50 border-2 border-purple-300">
            <div className="flex items-start gap-3 mb-4">
              <CheckCircle className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-xl font-bold text-purple-900 mb-2">Contexto Real da LATAM</h3>
                <p className="text-purple-900 leading-relaxed">
                  {problem.realWorldExample}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Ações */}
        <div className="flex gap-4 justify-center mt-12">
          <Link href={`/comparacao/${problem.id}`}>
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
              Ver Comparação Antes/Depois
            </Button>
          </Link>
          <Link href="/">
            <Button size="lg" variant="outline">
              Voltar para Lista
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
