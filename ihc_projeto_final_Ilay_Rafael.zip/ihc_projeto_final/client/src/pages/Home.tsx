import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ihcProblems } from "@/data/problems";
import { Link } from "wouter";
import { ArrowRight, AlertCircle } from "lucide-react";
import Header from "@/components/Header";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-700 hover:bg-blue-200">
            Análise Baseada em Website Real
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Problemas de IHC Identificados
          </h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Análise crítica de 5 problemas reais de Interação Humano-Computador encontrados no website oficial da LATAM Airlines Brasil, 
            fundamentada nas <strong>10 Heurísticas de Usabilidade de Jakob Nielsen</strong>.
          </p>
        </div>

        {/* Lista de Problemas */}
        <div className="grid gap-6 max-w-5xl mx-auto">
          {ihcProblems.map((problem, index) => (
            <Card 
              key={problem.id} 
              className="p-6 hover:shadow-xl transition-all duration-300 border-l-4 border-l-blue-500"
            >
              <div className="flex items-start gap-4">
                {/* Número */}
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-xl font-bold text-blue-600">{index + 1}</span>
                  </div>
                </div>

                {/* Conteúdo */}
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">
                        {problem.title}
                      </h3>
                      <Badge variant="outline" className="text-xs">
                        Heurística #{problem.heuristicNumber}: {problem.heuristic}
                      </Badge>
                    </div>
                    <AlertCircle className="h-6 w-6 text-amber-500 flex-shrink-0" />
                  </div>

                  <p className="text-slate-700 mb-4 leading-relaxed">
                    {problem.shortDescription}
                  </p>

                  <div className="flex gap-3">
                    <Link href={`/problema/${problem.id}`}>
                      <Button variant="default" className="bg-blue-600 hover:bg-blue-700">
                        Ver Detalhes
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                    <Link href={`/comparacao/${problem.id}`}>
                      <Button variant="outline">
                        Ver Comparação
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Footer Info */}
        <div className="mt-16 text-center">
          <Card className="p-6 bg-blue-50 border-blue-200 max-w-3xl mx-auto">
            <p className="text-sm text-slate-700">
              <strong>Metodologia:</strong> Esta análise foi realizada através de inspeção heurística do website oficial da LATAM Airlines Brasil 
              (<a href="https://www.latamairlines.com/br/pt" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">latamairlines.com/br/pt</a>), 
              capturando elementos reais de HTML e identificando violações das heurísticas de usabilidade de Nielsen (1994).
            </p>
          </Card>
        </div>
      </main>
    </div>
  );
}
