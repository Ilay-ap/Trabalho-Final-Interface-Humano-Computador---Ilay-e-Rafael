import { Plane } from "lucide-react";
import { Link } from "wouter";

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo e Título */}
          <Link href="/">
            <a className="flex items-center gap-3 hover:opacity-90 transition-opacity">
              <div className="bg-white p-2 rounded-lg shadow-md">
                <Plane className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Análise de IHC</h1>
                <p className="text-xs text-blue-100">LATAM Airlines Brasil</p>
              </div>
            </a>
          </Link>

          {/* Navegação */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/">
              <a className="text-sm font-medium hover:text-blue-100 transition-colors">
                Problemas
              </a>
            </Link>
            <a 
              href="https://www.latamairlines.com/br/pt" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm font-medium hover:text-blue-100 transition-colors"
            >
              Website LATAM
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}
