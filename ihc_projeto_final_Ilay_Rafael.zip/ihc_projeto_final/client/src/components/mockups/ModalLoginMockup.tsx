import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Check, Plane, CreditCard, Luggage } from "lucide-react";

interface ModalLoginMockupProps {
  variant: "problem" | "solution";
}

export default function ModalLoginMockup({ variant }: ModalLoginMockupProps) {
  return (
    <div className="relative bg-gradient-to-b from-blue-900 to-blue-700 p-4 md:p-6 rounded-lg min-h-[350px] max-h-[500px] flex items-center justify-center overflow-hidden">
      {/* Conteúdo de fundo (simulando site) */}
      <div className="absolute inset-0 p-8 opacity-40">
        <div className="bg-white/20 h-20 rounded mb-4" />
        <div className="bg-white/20 h-40 rounded mb-4" />
        <div className="bg-white/20 h-32 rounded" />
      </div>

      {variant === "problem" ? (
        /* PROBLEMA: Modal intrusivo bloqueando tudo */
        <Card className="relative z-10 w-full max-w-md p-6 shadow-2xl scale-95">
          <button className="absolute top-3 right-3 text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>

          <h2 className="text-xl font-bold text-slate-900 mb-4">
            Faça seu login na LATAM para:
          </h2>

          <div className="space-y-3 mb-6">
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-slate-700">
                Acumular e trocar Milhas LATAM Pass por passagens e mais.
              </p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-slate-700">
                Administrar suas viagens.
              </p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-slate-700">
                Pagar com PIX.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
              Criar conta
            </Button>
            <Button variant="outline" className="w-full">
              Fazer login
            </Button>
          </div>

          <div className="mt-4 p-3 bg-red-50 border-l-4 border-red-500 rounded">
            <p className="text-xs text-red-900">
              <strong>❌ Problema:</strong> Modal aparece automaticamente bloqueando todo o conteúdo. Usuário é forçado a tomar ação antes de explorar o site.
            </p>
          </div>
        </Card>
      ) : (
        /* SOLUÇÃO: Banner discreto no topo */
        <div className="relative z-10 w-full max-w-3xl scale-90 origin-top">
          <Card className="p-3 bg-gradient-to-r from-blue-50 to-green-50 border-2 border-blue-300 mb-3">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Plane className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-bold text-sm text-slate-900">
                    Entre e ganhe 500 milhas bônus! 🎁
                  </p>
                  <p className="text-xs text-slate-600">
                    Acumule pontos, pague com PIX e administre suas viagens
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-xs">
                  Criar conta
                </Button>
                <Button size="sm" variant="outline" className="text-xs">
                  Fazer login
                </Button>
              </div>
            </div>
          </Card>

          {/* Conteúdo principal visível */}
          <div className="space-y-3">
            <Card className="p-4 bg-white">
              <h3 className="text-base font-bold text-slate-900 mb-3">
                Para onde você quer ir?
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 border-2 border-slate-300 rounded-lg">
                  <p className="text-xs text-slate-600 mb-1">De</p>
                  <p className="font-bold text-sm">São Paulo - GRU</p>
                </div>
                <div className="p-3 border-2 border-slate-300 rounded-lg">
                  <p className="text-xs text-slate-600 mb-1">Para</p>
                  <p className="font-bold text-sm">Rio de Janeiro - GIG</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-white">
              <h3 className="text-sm font-bold text-slate-900 mb-2">
                Ofertas da semana
              </h3>
              <div className="grid grid-cols-3 gap-2">
                <div className="p-2 bg-blue-50 rounded border border-blue-200">
                  <p className="text-xs font-semibold">Salvador</p>
                  <p className="text-[10px] text-slate-600">A partir de</p>
                  <p className="text-sm font-bold text-blue-600">R$ 299</p>
                </div>
                <div className="p-2 bg-blue-50 rounded border border-blue-200">
                  <p className="text-xs font-semibold">Fortaleza</p>
                  <p className="text-[10px] text-slate-600">A partir de</p>
                  <p className="text-sm font-bold text-blue-600">R$ 349</p>
                </div>
                <div className="p-2 bg-blue-50 rounded border border-blue-200">
                  <p className="text-xs font-semibold">Recife</p>
                  <p className="text-[10px] text-slate-600">A partir de</p>
                  <p className="text-sm font-bold text-blue-600">R$ 379</p>
                </div>
              </div>
            </Card>
          </div>

          <div className="mt-3 p-3 bg-green-50 border-l-4 border-green-500 rounded">
            <p className="text-xs text-green-900">
              <strong>✓ Solução:</strong> Banner discreto no topo (não intrusivo) + conteúdo principal totalmente visível e acessível. Usuário tem liberdade para explorar antes de decidir fazer login.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
