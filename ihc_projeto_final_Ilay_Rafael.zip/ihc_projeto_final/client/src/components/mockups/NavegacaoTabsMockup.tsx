import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plane, Package, Hotel, Car, Shield, ArrowUp, Smartphone, Ticket, ChevronDown } from "lucide-react";

interface NavegacaoTabsMockupProps {
  variant: "problem" | "solution";
}

export default function NavegacaoTabsMockup({ variant }: NavegacaoTabsMockupProps) {
  return (
    <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-4 md:p-6 rounded-lg min-h-[350px] max-h-[500px] overflow-auto">
      <Card className="p-4 md:p-6 max-w-3xl mx-auto scale-95">
        <h2 className="text-lg md:text-xl font-bold text-slate-900 mb-4">
          Para onde você quer ir?
        </h2>

        {variant === "problem" ? (
          /* PROBLEMA: 8 tabs sem hierarquia */
          <div className="space-y-6">
            <div className="flex flex-wrap gap-2">
              <button className="px-4 py-3 bg-blue-600 text-white rounded-lg font-medium flex items-center gap-2">
                <Plane className="h-5 w-5" />
                Voos
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Package className="h-5 w-5" />
                Pacotes
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Hotel className="h-5 w-5" />
                Hospedagem
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Car className="h-5 w-5" />
                Carros
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Seguros
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <ArrowUp className="h-5 w-5" />
                Upgrade
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Smartphone className="h-5 w-5" />
                eSIM
              </button>
              <button className="px-4 py-3 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2">
                <Ticket className="h-5 w-5" />
                Universal
              </button>
            </div>

            <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
              <p className="text-sm text-amber-900">
                <strong>🤔 Confusão do usuário:</strong> "Nossa, quanta opção! Eu só quero comprar uma passagem simples. Qual devo escolher? O que é eSIM? E Universal?"
              </p>
            </div>

            <Card className="p-6 bg-white border-2 border-slate-200">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 mb-2 block">De</label>
                  <input
                    type="text"
                    placeholder="Insira uma origem"
                    className="w-full border-2 border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-700 mb-2 block">Para</label>
                  <input
                    type="text"
                    placeholder="Insira um destino"
                    className="w-full border-2 border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </Card>

            <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
              <p className="text-sm text-red-900">
                <strong>❌ Problema:</strong> 8 tabs com mesmo peso visual criando sobrecarga cognitiva. Usuário perde tempo tentando entender qual é a melhor opção. Falta hierarquia clara.
              </p>
            </div>
          </div>
        ) : (
          /* SOLUÇÃO: Hierarquia clara com agrupamento */
          <div className="space-y-6">
            <div className="flex flex-wrap gap-3 items-center">
              {/* Tab principal destacada */}
              <button className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-bold text-lg shadow-lg flex items-center gap-2 border-2 border-blue-400">
                <Plane className="h-6 w-6" />
                Voos
                <Badge className="ml-2 bg-yellow-400 text-yellow-900">Principal</Badge>
              </button>

              {/* Pacotes como secundário */}
              <button className="px-5 py-4 bg-purple-100 text-purple-700 rounded-lg font-semibold hover:bg-purple-200 flex items-center gap-2 border-2 border-purple-300">
                <Package className="h-5 w-5" />
                Pacotes Completos
              </button>

              {/* Mais Serviços agrupado */}
              <div className="relative group">
                <button className="px-5 py-4 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200 flex items-center gap-2 border-2 border-slate-300">
                  Mais Serviços
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                {/* Dropdown simulado */}
                <div className="absolute top-full left-0 mt-2 bg-white rounded-lg shadow-xl border-2 border-slate-200 p-2 min-w-[200px] opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <button className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded flex items-center gap-2 text-sm">
                    <Hotel className="h-4 w-4" />
                    Hospedagem
                  </button>
                  <button className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded flex items-center gap-2 text-sm">
                    <Car className="h-4 w-4" />
                    Carros
                  </button>
                  <button className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded flex items-center gap-2 text-sm">
                    <Shield className="h-4 w-4" />
                    Seguros
                  </button>
                  <button className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded flex items-center gap-2 text-sm">
                    <Smartphone className="h-4 w-4" />
                    eSIM
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                <strong>💡 Foco claro:</strong> "Voos" está em destaque como opção principal. Outras opções estão organizadas e não competem pela atenção. Simples e direto!
              </p>
            </div>

            <Card className="p-6 bg-white border-2 border-blue-200">
              <h3 className="text-lg font-bold text-slate-900 mb-4">
                Buscar Voos
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 mb-2 block">De</label>
                  <input
                    type="text"
                    placeholder="Insira uma origem"
                    className="w-full border-2 border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-700 mb-2 block">Para</label>
                  <input
                    type="text"
                    placeholder="Insira um destino"
                    className="w-full border-2 border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </Card>

            <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
              <p className="text-sm text-green-900">
                <strong>✓ Solução:</strong> Hierarquia visual clara com "Voos" em destaque. Serviços secundários agrupados em "Mais Serviços". Reduz sobrecarga cognitiva e facilita decisão.
              </p>
            </div>
          </div>
        )}

        <div className="mt-6 text-center">
          <p className="text-sm text-slate-600">
            {variant === "problem" 
              ? "Muitas opções → Confusão → Paralisia de decisão"
              : "Hierarquia clara → Foco → Decisão rápida"}
          </p>
        </div>
      </Card>
    </div>
  );
}
