import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plane, Info, AlertCircle, Check } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface OfertasPrecoMockupProps {
  variant: "problem" | "solution";
}

export default function OfertasPrecoMockup({ variant }: OfertasPrecoMockupProps) {
  return (
    <div className="bg-gradient-to-b from-blue-50 to-white p-4 md:p-6 rounded-lg min-h-[350px] max-h-[550px] overflow-auto">
      <div className="max-w-4xl mx-auto scale-90">
        <div className="mb-4">
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Descubra sua próxima viagem
          </h2>
          <p className="text-slate-600">
            Ofertas de voo saindo de <strong>São Paulo - Guarulhos Intl.</strong>
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {variant === "problem" ? (
            /* PROBLEMA: Preço incompleto enganoso */
            <>
              <Card className="p-6 border-2 border-blue-200 hover:shadow-lg transition-shadow">
                <Badge className="mb-3 bg-red-600">OFERTA</Badge>
                <div className="flex items-center gap-2 mb-2">
                  <Plane className="h-5 w-5 text-blue-600" />
                  <span className="text-sm text-slate-600">Voo direto</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">Salvador da Bahia</h3>
                <p className="text-sm text-slate-600 mb-4">Somente ida • 26/11/25 • Econômica</p>
                
                <div className="mb-4">
                  <p className="text-4xl font-bold text-blue-600">R$ 299</p>
                </div>

                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Ver oferta
                </Button>
              </Card>

              <Card className="p-6 border-2 border-blue-200 hover:shadow-lg transition-shadow">
                <Badge className="mb-3 bg-red-600">OFERTA</Badge>
                <div className="flex items-center gap-2 mb-2">
                  <Plane className="h-5 w-5 text-blue-600" />
                  <span className="text-sm text-slate-600">Voo direto</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">Fortaleza</h3>
                <p className="text-sm text-slate-600 mb-4">Somente ida • 28/11/25 • Econômica</p>
                
                <div className="mb-4">
                  <p className="text-4xl font-bold text-blue-600">R$ 349</p>
                </div>

                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Ver oferta
                </Button>
              </Card>

              <Card className="p-6 border-2 border-blue-200 hover:shadow-lg transition-shadow">
                <Badge className="mb-3 bg-red-600">OFERTA</Badge>
                <div className="flex items-center gap-2 mb-2">
                  <Plane className="h-5 w-5 text-blue-600" />
                  <span className="text-sm text-slate-600">Voo direto</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">Recife</h3>
                <p className="text-sm text-slate-600 mb-4">Somente ida • 28/11/25 • Econômica</p>
                
                <div className="mb-4">
                  <p className="text-4xl font-bold text-blue-600">R$ 379</p>
                </div>

                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Ver oferta
                </Button>
              </Card>
            </>
          ) : (
            /* SOLUÇÃO: Preço completo transparente */
            <TooltipProvider>
              <>
                <Card className="p-6 border-2 border-green-200 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-red-600">OFERTA</Badge>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                      Preço final
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Plane className="h-5 w-5 text-blue-600" />
                    <span className="text-sm text-slate-600">Voo direto</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Salvador da Bahia</h3>
                  <p className="text-sm text-slate-600 mb-4">Somente ida • 26/11/25 • Econômica</p>
                  
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-4xl font-bold text-blue-600">R$ 466</p>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-5 w-5 text-blue-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <div className="text-sm space-y-1">
                            <p><strong>Detalhes do preço:</strong></p>
                            <p>Tarifa base: R$ 299</p>
                            <p>Taxas aeroportuárias: R$ 87</p>
                            <p>Bagagem despachada: R$ 80</p>
                            <hr className="my-2" />
                            <p><strong>Total: R$ 466</strong></p>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-xs text-slate-500">Inclui taxas + bagagem</p>
                  </div>

                  <div className="bg-green-50 p-3 rounded border border-green-200 mb-4">
                    <div className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-green-900">
                        <strong>Incluso:</strong> Bagagem de mão (10kg) + Bagagem despachada (23kg)
                      </p>
                    </div>
                  </div>

                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Ver oferta
                  </Button>
                </Card>

                <Card className="p-6 border-2 border-green-200 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-red-600">OFERTA</Badge>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                      Preço final
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Plane className="h-5 w-5 text-blue-600" />
                    <span className="text-sm text-slate-600">Voo direto</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Fortaleza</h3>
                  <p className="text-sm text-slate-600 mb-4">Somente ida • 28/11/25 • Econômica</p>
                  
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-4xl font-bold text-blue-600">R$ 516</p>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-5 w-5 text-blue-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <div className="text-sm space-y-1">
                            <p><strong>Detalhes do preço:</strong></p>
                            <p>Tarifa base: R$ 349</p>
                            <p>Taxas aeroportuárias: R$ 87</p>
                            <p>Bagagem despachada: R$ 80</p>
                            <hr className="my-2" />
                            <p><strong>Total: R$ 516</strong></p>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-xs text-slate-500">Inclui taxas + bagagem</p>
                  </div>

                  <div className="bg-green-50 p-3 rounded border border-green-200 mb-4">
                    <div className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-green-900">
                        <strong>Incluso:</strong> Bagagem de mão (10kg) + Bagagem despachada (23kg)
                      </p>
                    </div>
                  </div>

                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Ver oferta
                  </Button>
                </Card>

                <Card className="p-6 border-2 border-green-200 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-red-600">OFERTA</Badge>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                      Preço final
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <Plane className="h-5 w-5 text-blue-600" />
                    <span className="text-sm text-slate-600">Voo direto</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Recife</h3>
                  <p className="text-sm text-slate-600 mb-4">Somente ida • 28/11/25 • Econômica</p>
                  
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="text-4xl font-bold text-blue-600">R$ 546</p>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-5 w-5 text-blue-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <div className="text-sm space-y-1">
                            <p><strong>Detalhes do preço:</strong></p>
                            <p>Tarifa base: R$ 379</p>
                            <p>Taxas aeroportuárias: R$ 87</p>
                            <p>Bagagem despachada: R$ 80</p>
                            <hr className="my-2" />
                            <p><strong>Total: R$ 546</strong></p>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-xs text-slate-500">Inclui taxas + bagagem</p>
                  </div>

                  <div className="bg-green-50 p-3 rounded border border-green-200 mb-4">
                    <div className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-green-900">
                        <strong>Incluso:</strong> Bagagem de mão (10kg) + Bagagem despachada (23kg)
                      </p>
                    </div>
                  </div>

                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Ver oferta
                  </Button>
                </Card>
              </>
            </TooltipProvider>
          )}
        </div>

        {/* Explicação */}
        {variant === "problem" ? (
          <div className="mt-8 p-4 bg-red-50 border-l-4 border-red-500 rounded">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-6 w-6 text-red-600 flex-shrink-0" />
              <div>
                <p className="text-sm text-red-900 mb-2">
                  <strong>❌ Problema:</strong> Preços mostram apenas tarifa base (R$ 299, R$ 349, R$ 379) sem indicar que taxas (R$ 87) e bagagem (R$ 80) serão cobradas no checkout.
                </p>
                <p className="text-sm text-red-800">
                  Usuário vê "R$ 299" mas paga "R$ 466" no final. Sensação de engano e abandono de carrinho.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-8 p-4 bg-green-50 border-l-4 border-green-500 rounded">
            <div className="flex items-start gap-3">
              <Check className="h-6 w-6 text-green-600 flex-shrink-0" />
              <div>
                <p className="text-sm text-green-900 mb-2">
                  <strong>✓ Solução:</strong> Preço final completo (R$ 466, R$ 516, R$ 546) com selo "Preço final". Tooltip mostra breakdown detalhado. Lista o que está incluso.
                </p>
                <p className="text-sm text-green-800">
                  Transparência total desde o início. Usuário sabe exatamente quanto vai pagar. Sem surpresas no checkout.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
