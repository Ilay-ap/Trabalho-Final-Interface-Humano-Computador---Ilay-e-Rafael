import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Plane, Calendar, Users, ArrowLeftRight } from "lucide-react";

interface FormularioFeedbackMockupProps {
  variant: "problem" | "solution";
}

export default function FormularioFeedbackMockup({ variant }: FormularioFeedbackMockupProps) {
  const [focusedField, setFocusedField] = useState<string | null>(null);

  return (
    <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-4 md:p-6 rounded-lg min-h-[350px] max-h-[500px] overflow-hidden">
      <Card className="p-4 md:p-6 max-w-3xl mx-auto scale-95">
        <h2 className="text-lg md:text-xl font-bold text-slate-900 mb-4">
          Para onde você quer ir?
        </h2>

        <div className="space-y-6">
          {/* Tipo de viagem */}
          <div className="flex gap-4">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium">
              Ida e volta
            </button>
            <button className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium hover:bg-slate-200">
              Somente ida
            </button>
          </div>

          {/* Campos de origem e destino */}
          <div className="grid md:grid-cols-2 gap-4">
            {/* Campo De (Origem) */}
            <div>
              <label className={`text-sm font-medium mb-2 block transition-colors ${
                variant === "solution" && focusedField === "origem" 
                  ? "text-blue-600" 
                  : "text-slate-700"
              }`}>
                De
              </label>
              <div className={`relative ${
                variant === "problem"
                  ? "border-2 border-slate-300 rounded-lg p-4 bg-white"
                  : focusedField === "origem"
                  ? "border-4 border-blue-500 rounded-lg p-4 bg-white shadow-lg shadow-blue-200 ring-2 ring-blue-300"
                  : "border-2 border-slate-300 rounded-lg p-4 bg-white hover:border-slate-400"
              }`}>
                <input
                  type="text"
                  placeholder="Insira uma origem"
                  onFocus={() => variant === "solution" && setFocusedField("origem")}
                  onBlur={() => variant === "solution" && setFocusedField(null)}
                  className="w-full outline-none text-slate-900 font-medium"
                  defaultValue={focusedField === "origem" ? "São Paulo" : ""}
                />
                {variant === "solution" && focusedField === "origem" && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <Plane className="h-5 w-5 text-blue-600" />
                  </div>
                )}
              </div>
            </div>

            {/* Botão inverter */}
            <div className="hidden md:flex items-end justify-center pb-4">
              <button className="p-2 rounded-full bg-slate-100 hover:bg-slate-200">
                <ArrowLeftRight className="h-5 w-5 text-slate-600" />
              </button>
            </div>

            {/* Campo Para (Destino) */}
            <div>
              <label className={`text-sm font-medium mb-2 block transition-colors ${
                variant === "solution" && focusedField === "destino" 
                  ? "text-blue-600" 
                  : "text-slate-700"
              }`}>
                Para
              </label>
              <div className={`relative ${
                variant === "problem"
                  ? "border-2 border-slate-300 rounded-lg p-4 bg-white"
                  : focusedField === "destino"
                  ? "border-4 border-blue-500 rounded-lg p-4 bg-white shadow-lg shadow-blue-200 ring-2 ring-blue-300"
                  : "border-2 border-slate-300 rounded-lg p-4 bg-white hover:border-slate-400"
              }`}>
                <input
                  type="text"
                  placeholder="Insira um destino"
                  onFocus={() => variant === "solution" && setFocusedField("destino")}
                  onBlur={() => variant === "solution" && setFocusedField(null)}
                  className="w-full outline-none text-slate-900 font-medium"
                />
                {variant === "solution" && focusedField === "destino" && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <Plane className="h-5 w-5 text-blue-600" />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Outros campos */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-2 block">
                Datas
              </label>
              <div className="border-2 border-slate-300 rounded-lg p-4 bg-white flex items-center gap-2">
                <Calendar className="h-5 w-5 text-slate-400" />
                <span className="text-slate-500">Selecionar as datas</span>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-2 block">
                Passageiros
              </label>
              <div className="border-2 border-slate-300 rounded-lg p-4 bg-white flex items-center gap-2">
                <Users className="h-5 w-5 text-slate-400" />
                <span className="text-slate-900 font-medium">1 Passageiro(s)</span>
              </div>
            </div>
          </div>

          <Button className="w-full bg-red-600 hover:bg-red-700 text-white text-lg py-6">
            Pesquisar
          </Button>
        </div>

        {/* Explicação */}
        {variant === "problem" ? (
          <div className="mt-6 p-4 bg-red-50 border-l-4 border-red-500 rounded">
            <p className="text-sm text-red-900">
              <strong>❌ Problema:</strong> Campos sem feedback visual claro de foco. Usuário não sabe qual campo está ativo ao digitar. Borda não muda significativamente.
            </p>
          </div>
        ) : (
          <div className="mt-6 p-4 bg-green-50 border-l-4 border-green-500 rounded">
            <p className="text-sm text-green-900">
              <strong>✓ Solução:</strong> Borda azul grossa (4px), sombra azul, label muda de cor, ícone aparece. Feedback visual imediato e claro de qual campo está ativo.
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
