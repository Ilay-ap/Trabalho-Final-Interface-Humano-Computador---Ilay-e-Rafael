export { default as ModalLoginMockup } from './ModalLoginMockup';
export { default as FormularioFeedbackMockup } from './FormularioFeedbackMockup';
export { default as LatamPassMockup } from './LatamPassMockup';
export { default as OfertasPrecoMockup } from './OfertasPrecoMockup';
export { default as NavegacaoTabsMockup } from './NavegacaoTabsMockup';
