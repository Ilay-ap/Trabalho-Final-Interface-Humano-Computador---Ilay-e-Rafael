import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plane, Gift, Star, Luggage, Info, HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface LatamPassMockupProps {
  variant: "problem" | "solution";
}

export default function LatamPassMockup({ variant }: LatamPassMockupProps) {
  return (
    <div className="bg-gradient-to-b from-slate-50 to-white p-4 md:p-6 rounded-lg min-h-[350px] max-h-[550px] overflow-auto">
      <div className="max-w-3xl mx-auto scale-90">
        <div className="text-center mb-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="bg-gradient-to-br from-purple-600 to-blue-600 p-3 rounded-lg">
              <Gift className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-xl font-bold text-slate-900">LATAM Pass</h2>
          </div>
          <p className="text-slate-600">
            {variant === "problem" 
              ? "Programa de fidelidade da LATAM Airlines"
              : "Ganhe pontos a cada voo e troque por passagens grátis"}
          </p>
        </div>

        {variant === "problem" ? (
          /* PROBLEMA: Jargão técnico confuso */
          <div className="space-y-6">
            <Card className="p-6 bg-white border-2 border-slate-200">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Star className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2 text-lg">
                      Acumule Milhas LATAM Pass
                    </h3>
                    <p className="text-slate-700">
                      Acumule <span className="bg-yellow-200 px-1 font-bold">milhas</span> em todas as suas compras e voos.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Luggage className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2 text-lg">
                      Benefícios Exclusivos
                    </h3>
                    <p className="text-slate-700">
                      Obtenha benefícios em bagagem, <span className="bg-yellow-200 px-1 font-bold">Upgrade de cabine</span> e mais.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Plane className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2 text-lg">
                      Resgate Passagens
                    </h3>
                    <p className="text-slate-700">
                      <span className="bg-yellow-200 px-1 font-bold">Resgate</span> passagens e produtos com suas <span className="bg-yellow-200 px-1 font-bold">Milhas LATAM Pass</span>.
                    </p>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-amber-50 border-2 border-amber-300">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-6 w-6 text-amber-600 flex-shrink-0" />
                <div>
                  <p className="text-sm text-amber-900">
                    <strong>Dúvida comum:</strong> "O que são milhas? Como funciona upgrade de cabine? O que é resgatar?"
                  </p>
                </div>
              </div>
            </Card>

            <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
              <p className="text-sm text-red-900">
                <strong>❌ Problema:</strong> Termos técnicos ('milhas', 'upgrade de cabine', 'resgate') sem explicação clara. Usuários iniciantes não entendem.
              </p>
            </div>
          </div>
        ) : (
          /* SOLUÇÃO: Linguagem clara com explicações */
          <TooltipProvider>
            <div className="space-y-6">
              <Card className="p-6 bg-white border-2 border-purple-200 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="bg-purple-100 p-3 rounded-lg flex-shrink-0">
                    <Star className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-slate-900 text-lg">
                        Ganhe Pontos LATAM
                      </h3>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-purple-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p>A cada voo, você ganha pontos (chamados de "milhas"). Quanto mais você voa, mais pontos acumula!</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-slate-700 mb-3">
                      A cada voo, você ganha pontos que podem ser trocados por passagens grátis
                    </p>
                    <div className="bg-purple-50 p-3 rounded border border-purple-200">
                      <p className="text-sm text-purple-900 font-semibold">
                        📍 Exemplo: Voe de SP a Rio = ganhe 500 pontos
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-white border-2 border-blue-200 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                    <Luggage className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-slate-900 text-lg">
                        Melhoria de Assento
                      </h3>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-blue-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p>Use seus pontos para mudar de classe econômica para classe executiva (assentos mais confortáveis, comida melhor, mais espaço).</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-slate-700 mb-3">
                      Use pontos para melhorar seu assento (de econômica para executiva)
                    </p>
                    <div className="bg-blue-50 p-3 rounded border border-blue-200">
                      <p className="text-sm text-blue-900 font-semibold">
                        📍 Exemplo: 5.000 pontos = upgrade para classe executiva
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-white border-2 border-green-200 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="bg-green-100 p-3 rounded-lg flex-shrink-0">
                    <Plane className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold text-slate-900 text-lg">
                        Troque por Passagens Grátis
                      </h3>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-green-600" />
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p>Quando você junta pontos suficientes, pode trocar por uma passagem aérea sem pagar nada!</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <p className="text-slate-700 mb-3">
                      Junte pontos e troque por passagens sem pagar nada
                    </p>
                    <div className="bg-green-50 p-3 rounded border border-green-200">
                      <p className="text-sm text-green-900 font-semibold">
                        📍 Exemplo: 10.000 pontos = 1 passagem grátis SP→Rio
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-300">
                <h3 className="font-bold text-slate-900 mb-3">💡 Como Funciona (Simples)</h3>
                <div className="space-y-2 text-sm text-slate-700">
                  <p>1️⃣ Crie sua conta LATAM Pass (grátis)</p>
                  <p>2️⃣ Voe com a LATAM e ganhe pontos automaticamente</p>
                  <p>3️⃣ Junte 10.000 pontos = troque por 1 passagem grátis</p>
                </div>
              </Card>

              <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
                <p className="text-sm text-green-900">
                  <strong>✓ Solução:</strong> Linguagem simples e clara. Tooltips explicativos. Exemplos práticos com números reais. Usuários entendem facilmente.
                </p>
              </div>
            </div>
          </TooltipProvider>
        )}

        <div className="mt-8 text-center">
          <Button className="bg-purple-600 hover:bg-purple-700 text-white px-8">
            {variant === "problem" ? "Saiba mais" : "Criar conta grátis"}
          </Button>
        </div>
      </div>
    </div>
  );
}
